//
//  DetailedArticleViewController.swift
//  Task
//
//  Created by Venkat Reddy on 30/05/24.
//

import UIKit

class DetailedArticleViewController: UIViewController {

    //MARK: - Outlets
    @IBOutlet weak var detailsTblVw: UITableView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descriptionLbl: UILabel!
    @IBOutlet weak var contentLbl: UILabel!
    @IBOutlet weak var publishedAtLbl: UILabel!
    
    //MARK: - Variables
    var articleDetails : Articles!

    //MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = VC.ARTICE_DETAILS_TITLE

        if (articleDetails != nil) {
            registerTblVwNibs()
            detailsTblVw.dataSource = self
        }
    }
    
    //MARK: - Register Nibs
    func registerTblVwNibs(){
        detailsTblVw.register(UINib(nibName: DetailArticleTableViewCell.nibName, bundle: nil), forCellReuseIdentifier: DetailArticleTableViewCell.identifier)
    }
    
    static func getInstance()-> DetailedArticleViewController{
        return UIStoryboard.init(name: STORYBOARD.MAIN, bundle: nil).instantiateViewController(withIdentifier: VC.DAVC) as! DetailedArticleViewController
    }

    func formatDate(_ dateString: String) -> String {
        // Replace 'T' with a space and remove 'Z'
        let formattedDate = dateString.replacingOccurrences(of: "T", with: " ").replacingOccurrences(of: "Z", with: "")
        return formattedDate
    }
}

extension DetailedArticleViewController: UITableViewDataSource, UITableViewDelegate {
    //MARK: - UITableView DataSource & Delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = detailsTblVw.dequeueReusableCell(withIdentifier: DetailArticleTableViewCell.identifier) as! DetailArticleTableViewCell
        cell.selectionStyle = .none
        switch indexPath.row {
        case 0:
            cell.titleLbl.text = "Title : \(articleDetails.title ?? "")"
        case 1:
            cell.titleLbl.text = "Description : \(articleDetails.description ?? "")"
        case 2:
            cell.titleLbl.text =  "Content : \(articleDetails.content ?? "")"
        case 3:
            cell.titleLbl.text =  "Date : " + formatDate(articleDetails.publishedAt ?? "")
        default:
            cell.titleLbl.text = "Title : \(articleDetails.title ?? "")"
        }
        return cell
    }
}
