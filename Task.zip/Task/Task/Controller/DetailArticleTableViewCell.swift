//
//  DetailArticleTableViewCell.swift
//  Task
//
//  Created by Venkat Reddy on 30/05/24.
//

import UIKit

class DetailArticleTableViewCell: UITableViewCell {
    class var nibName: String{
        return "\(self)"
    }
    class var identifier: String{
        return "\(self)"
    }

    @IBOutlet weak var titleLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
