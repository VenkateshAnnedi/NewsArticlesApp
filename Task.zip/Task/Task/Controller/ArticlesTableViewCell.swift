//
//  ArticlesTableViewCell.swift
//  Task
//
//  Created by Venkat Reddy on 30/05/24.
//

import UIKit

class ArticlesTableViewCell: UITableViewCell {
    class var nibName: String{
        return "\(self)"
    }
    class var identifier: String{
        return "\(self)"
    }

    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descriptionLbl: UILabel!
    @IBOutlet weak var publishedAtLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func loadArticleData(article:Articles){
        titleLbl.text = article.title
        descriptionLbl.text = article.description
        publishedAtLbl.text = formatDate(article.publishedAt ?? "")
    }
    
    func formatDate(_ dateString: String) -> String {
        // Replace 'T' with a space and remove 'Z'
        let formattedDate = dateString.replacingOccurrences(of: "T", with: " ").replacingOccurrences(of: "Z", with: "")
        return formattedDate
    }
}
