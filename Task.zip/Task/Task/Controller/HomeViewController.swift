//
//  HomeViewController.swift
//  Task
//
//  Created by Venkat Reddy on 30/05/24.
//

import UIKit

class HomeViewController: UIViewController {
    
    //MARK: - Outlets
    @IBOutlet weak var articlesTblVw: UITableView!
    @IBOutlet weak var searchVw: UIView!
    @IBOutlet weak var searchTf: UITextField!
    @IBOutlet weak var clearTextImgVw: UIImageView!
    @IBOutlet weak var clearTextBtn: UIButton!

    //MARK: - Variables
    var filterBtn = UIBarButtonItem()
    var articles: [Articles] = []
    var filterArticles = [Articles]()

    //MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        title = VC.HOME_TITLE
        registerTblVwNibs()
        setUpBarButtonItem()
        if Reachability.isNetworkAvailable() {
            showLoadingIndicator()
            getNewsArticles()
        }else{
            UIAlertController.showAlert(vc: self, title: ALERT.OOPS, message: ALERT.INTERNET_MSG)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configureView()
    }
}

extension HomeViewController {
    //MARK: - Register Nibs
    func registerTblVwNibs(){
        articlesTblVw.register(UINib(nibName: ArticlesTableViewCell.nibName, bundle: nil), forCellReuseIdentifier: ArticlesTableViewCell.identifier)
    }
    
    //MARK: - Configure View
    func configureView() {
        searchVw.layer.borderWidth = 0.5
        searchVw.layer.borderColor = UIColor.lightGray.cgColor
        searchVw.layer.cornerRadius = 8.0
        
        articlesTblVw.dataSource = self
        articlesTblVw.delegate = self
        
        searchTf.text = ""
        searchTf.delegate = self
        clearTextImgVw.isHidden = true
        clearTextBtn.isHidden = true
        hideKeyBoard()
    }
    
    //MARK: - SetUp barButtonItem
    func setUpBarButtonItem() {
        let filterBarBtn = UIBarButtonItem(title: "Filter", style: .plain, target: self, action: #selector(onTapFilterBtn))
        filterBarBtn.tintColor = UIColor.label
        self.navigationItem.rightBarButtonItem  = filterBarBtn
    }

    //MARK: - IB Actions
    @IBAction func onTapClearTextBtn(_ sender: UIButton) {
        searchTf.text = ""
        clearTextImgVw.isHidden = true
        clearTextBtn.isHidden = true
        articlesTblVw.isHidden = false
        hideKeyBoard()
        self.articles = self.filterArticles
        DispatchQueue.main.async {
            self.articlesTblVw .reloadData()
        }
    }
    
    @objc func onTapFilterBtn() {
        DispatchQueue.main.async {
            self.showFilterCategories()
        }
    }
}

extension HomeViewController {
    //MARK: - Get News Articles
    func getNewsArticles() {
        let url = URL(string: newsArticlesURL)!
        URLSession.shared.dataTask(with: url, completionHandler: { data,response,error -> Void in
            DispatchQueue.main.async {
                self.hideLoadingIndictor()
            }
            if let err = error {
                DispatchQueue.main.async {
                    UIAlertController.showAlert(vc: self, title: ALERT.OOPS, message: err.localizedDescription)
                }
            } else if let data = data {
                do {
                    let response = try JSONDecoder().decode(JsonBase.self, from: data)
                    DispatchQueue.main.async {
                        if response.status == RESPONSE.STATUS {
                            if let articlesData = response.articles {
                                self.articles = [Articles]()
                                self.articles = articlesData
                                self.filterArticles = []
                                self.filterArticles = self.articles
                                self.articlesTblVw.reloadData()
                            }
                        } else{
                            DispatchQueue.main.async {
                                UIAlertController.showAlert(vc: self, title: ALERT.OOPS, message: response.status ?? "")
                            }
                        }
                    }
                } catch {
                    DispatchQueue.main.async {
                        UIAlertController.showAlert(vc: self, title: ALERT.OOPS, message: error.localizedDescription)
                    }
                }
            }
        })
        .resume()
    }
}

extension HomeViewController: UITableViewDataSource, UITableViewDelegate {
    //MARK: - UITableView DataSource & Delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = articlesTblVw.dequeueReusableCell(withIdentifier: ArticlesTableViewCell.identifier) as! ArticlesTableViewCell
        cell.selectionStyle = .none
        cell.loadArticleData(article: articles[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = DetailedArticleViewController.getInstance()
        vc.articleDetails = articles[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension HomeViewController : UITextFieldDelegate {
    //MARK: - UItextField Delegate
        func textFieldDidChangeSelection(_ textField: UITextField) {
            if textField.hasText {
                clearTextImgVw.isHidden = false
                clearTextBtn.isHidden = false
                searchNewsArticles(textField.text)
            }else{
                clearTextImgVw.isHidden = true
                clearTextBtn.isHidden = true
                self.articles = self.filterArticles
                DispatchQueue.main.async {
                    self.articlesTblVw .reloadData()
                }
            }
    }
    
    //MARK: - Search News Articles
    func searchNewsArticles(_ searchString: String?) {
        if (searchString?.count ?? 0) != 0 {
            articles = [AnyHashable]() as! [Articles]
            for item in filterArticles {
                if ((item.title as AnyObject).lowercased as NSString?)?.range(of: searchString?.lowercased() ?? "").location != NSNotFound {
                    articles.append(item)
                }else if ((item.description as AnyObject).lowercased as NSString?)?.range(of: searchString?.lowercased() ?? "").location != NSNotFound {
                    articles.append(item)
                }
            }
        } else {
            articles = filterArticles
        }
        
        if articles.count == 0 {
            self.articlesTblVw.isHidden = true
        } else {
            self.articlesTblVw.isHidden = false
            DispatchQueue.main.async {
                self.articlesTblVw.reloadData()
            }
        }
    }
}

extension UIViewController {
    //MARK: - Hide KeyBoard
    func hideKeyBoard() {
        DispatchQueue.main.async {
            self.view .endEditing(true)
        }
    }
    
    //MARK: - Show Filter Categories
    func showFilterCategories() {
        let alertController = UIAlertController(title: ALERT.CATEGORIES, message: "", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: ALERT.TECH, style: .default, handler: { action in
        }))
        alertController.addAction(UIAlertAction(title: ALERT.SPORTS, style: .default, handler: { action in
        }))
        alertController.addAction(UIAlertAction(title: ALERT.POLITICS, style: .default, handler: { action in
        }))
        alertController.addAction(UIAlertAction(title: ALERT.OTHERS, style: .default, handler: { action in
        }))
        alertController.addAction(UIAlertAction (title: ALERT.CANCEL, style: .cancel, handler: { (action:UIAlertAction) in
        }))
        DispatchQueue.main.async(execute: {
            self.present(alertController, animated: true)
        })
    }
}
