//
//  LoadingIndicator.swift
//  Task
//
//  Created by Venkat Reddy on 30/05/24.
//

import Foundation
import UIKit

var loadingAlertController = UIAlertController()

extension UIViewController {
    func showLoadingIndicator() {
        DispatchQueue.main.async {
            loadingAlertController = UIAlertController(title: "LOADING", message:"Please wait...", preferredStyle: .alert)
            loadingAlertController.view.tintColor = UIColor.blue
            let activityIndicator = UIActivityIndicatorView()
            if #available(iOS 13.0, *) {
                activityIndicator.style = .large
            } else {
                // Fallback on earlier versions
                activityIndicator.style = .whiteLarge
            }
            
            activityIndicator.translatesAutoresizingMaskIntoConstraints = false
            activityIndicator.tintColor = UIColor.blue
            loadingAlertController.view.addSubview(activityIndicator)

            let xConstraint: NSLayoutConstraint = NSLayoutConstraint(item: activityIndicator, attribute: .centerX, relatedBy: .equal, toItem: loadingAlertController.view, attribute: .centerX, multiplier: 1, constant: 0)
            let yConstraint: NSLayoutConstraint = NSLayoutConstraint(item: activityIndicator, attribute: .centerY, relatedBy: .equal, toItem: loadingAlertController.view, attribute: .centerY, multiplier: 1.4, constant: 0)

            NSLayoutConstraint.activate([ xConstraint, yConstraint])
            activityIndicator.isUserInteractionEnabled = false
            activityIndicator.startAnimating()

            let height: NSLayoutConstraint = NSLayoutConstraint(item: loadingAlertController.view as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 130)
            loadingAlertController.view.addConstraint(height);
            self.present(loadingAlertController, animated: true, completion: nil)
        }
    }

    func hideLoadingIndictor() {
        DispatchQueue.main.async {
            loadingAlertController.dismiss(animated: true, completion: nil)
        }
    }

}
