//
//  UIAlertController.swift
//  Task
//
//  Created by Venkat Reddy on 30/05/24.
//

import Foundation
import UIKit

extension UIAlertController {
    
    class func showAlert(vc:UIViewController,title:String,message:String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let dismissAction = UIAlertAction(title: "Ok", style: .cancel)
        alertController.addAction(dismissAction)
        vc.present(alertController, animated: true)
    }
}
