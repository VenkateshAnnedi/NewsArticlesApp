//
//  Constants.swift
//  Task
//
//  Created by Venkat Reddy on 30/05/24.
//

import Foundation
import UIKit

let newsArticlesURL = "https://newsapi.org/v2/everything?q=tesla&from=2024-04-30&sortBy=publishedAt&apiKey=4e84c78e9c6c47a5879c5701b7220001"

struct ALERT {
    static let OOPS = "Oops!"
    static let OK = "Ok"
    static let INTERNET_MSG = "The Internet connection appears to be offline."
    
    static let CATEGORIES = "Categories"
    static let TECH = "Technology"
    static let SPORTS = "Sports"
    static let POLITICS = "Polictis"
    static let OTHERS = "Others"
    static let CANCEL = "Cancel"
}

struct RESPONSE {
    static let STATUS = "ok"
}

struct STORYBOARD {
    static let MAIN = "Main"
}

struct VC {
    static let HOME_TITLE = "Articles"
    static let ARTICE_DETAILS_TITLE = "Article Details"
    static let DAVC = "DetailedArticleViewController"
}
